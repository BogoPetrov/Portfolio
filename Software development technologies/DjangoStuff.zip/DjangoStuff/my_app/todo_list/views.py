from django.shortcuts import render, redirect
from .models import List
from .forms import ListForm
from django.contrib import messages
from django.http import HttpResponseRedirect


def home(request):
    if request.method == 'POST':
        form = ListForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Item has been added to the list!')
            return redirect('home')

    all_items = List.objects.all()
    return render(request, 'home.html', {'all_items': all_items})


def about(request):
    context = {'first_name': 'John', 'last_name': 'Elder'}
    return render(request, 'about.html', context)


def delete(request, list_id):
    item = List.objects.get(pk=list_id)
    item.delete()
    messages.success(request, 'Item has been deleted!')
    return redirect('home')

def check(request, list_id):
    item = List.objects.get(pk=list_id)
    item.completed = not item.completed
    item.save()
    return redirect('home')
